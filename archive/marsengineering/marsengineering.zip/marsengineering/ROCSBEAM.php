<html>
<head>

<title>Mars Engineering - ROCSBEAM</title>

<?php
$currentPage = "ROCSBEAM";
include("METop.php");
?>

<h3>Ring of Communications Satelites Between Earth and Mars (ROCSBEAM)</h3>

<p>This is a proposal for establishing a permanent broadband comms link between Earth and Mars by installing a ring of 8 or more communications satelites in solar orbit between Earth and Mars.</p>

<?php
include("MEBottom.php");
?>

</html>