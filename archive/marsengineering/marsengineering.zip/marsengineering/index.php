<?php
header("Location:Welcome.php");
?>
