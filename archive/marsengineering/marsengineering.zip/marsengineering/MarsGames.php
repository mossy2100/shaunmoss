<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Mars Games</title>
<meta name="Generator" content="EditPlus">
<meta name="Author" content="">
<meta name="Keywords" content="">
<meta name="Description" content="">
</head>

<body>

<h3>Mars Games</h3>

<p><a href='http://www.gamespot.com/pc/action/commanderkeenepisodeimom/index.html'>Commander Keen Episode I: Marooned on Mars</a></p>

<p><a href='http://cureboredom.com/action/missionmars.shtml'>Mission To Mars</a><br>
free online space shooting game (Flash 6).  Pretty simple game, just shoot down buildings to make a clear landing space.</p>

<p><a href='http://www.cnn.com/TECH/specials/mars/games/games.html'>Shockwave Mars Games at CNN</a><br>
There are 3 "games".  "Target Mars" is a simple game where you select the launch date and the Delta-V in order for Pathfinder to successfully reach Mars.  </p>

<p><a href='http://www.tsgc.utexas.edu/everything/mars/games/'>Mars Game Center at the University of Texas</a><br>
8 simple games.</p>

<p><a href='http://www.nonvi.com/build_mars.html'>Build Mars for Palm OS Handhelds</a><br>
Teraform Mars within 1000 weeks so that humans can migrate from Earth.</p>


</body>
</html>
