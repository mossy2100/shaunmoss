
<!-- This include file provides the left-hand-side menu, plus top banner, etc., common to all pages. -->

<link rel="shortcut icon" href="Logo4.ico">

<style>
	body {background-color:white; margin-left:10; margin-right:10; margin-top:10; margin-bottom:10}
	body, p, td, th, ul, ol, h1, h2, h3, h4, h5, h6, a {font-family:Arial,Helvetica,sans-serif}
	body, p, td, ul, ol {font-size:13px; color:#000066}
	a {font-size:13px; color:red; text-decoration:none}
	a:hover {text-decoration:underline}
	th {font-size:15px}
	h1, h2, h3, h4, h5, h6 {color:cc0000}
	u {text-decoration:none; color:#33CCFF}
</style>

</head>
<body>

<table align=center cellspacing=0 cellpadding=0 border=0>
<tr>
<td><img src="images/Logo4(small).gif"></td>
<td align=center>
<p><img src="images/Banner4.gif"><br>
<i>The meek shall inherit the Earth - the rest of us are going to Mars!</i>
</td>
</tr>
</table>
<hr></p>

<!-- page content goes here -->
